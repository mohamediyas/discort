import { friendsActions } from "../actions/friendsActions";

const initialState = {
  friend: [],
  pendingFriendsInvitation: [],
  onlineUsers: [],
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case friendsActions.SET_PENDING_FRIENDS_INVITATION:
      return {
        ...state,
        pendingFriendsInvitation: action.pendingInvitation,
      };
    case friendsActions.SET_FRIENDS:
      return {
        ...state,
        friend: action.friend,
      };
    case friendsActions.SET_ONLINE_USER:
      return {
        ...state,
        onlineUsers: action.onlineUsers,
      };
    default:
      return state;
  }
};

export default reducer;
