import React from "react";
import CustomPrimaryButton from "../../shared/components/CustomPrimaryButton";
import RedirectInfo from "../../shared/components/RedirectInfo";
import { useHistory } from "react-router-dom";
import { Tooltip } from "@mui/material";

const RegisterPageFooter = ({ handleRegister, isFormValid }) => {
  const history = useHistory();

  const handlePushToLoginrPage = () => {
    history.push("/login");
  };

  const getFormNotValidMessage = () => {
    return "Enter correct valid email and password";
  };

  const getFormValidMessage = () => {
    return "Press to register !";
  };

  return (
    <>
      <Tooltip
        title={!isFormValid ? getFormNotValidMessage() : getFormValidMessage()}
      >
        <div>
          <CustomPrimaryButton
            label={"Register"}
            additionalStyles={{ marginTop: "30px" }}
            disabled={!isFormValid}
            onClick={handleRegister}
          />
        </div>
      </Tooltip>

      <RedirectInfo
        text={""}
        redirectText={"Already have an account ?"}
        additionalStyles={{ marginTop: "5px" }}
        redirectHandler={handlePushToLoginrPage}
      />
    </>
  );
};

export default RegisterPageFooter;
