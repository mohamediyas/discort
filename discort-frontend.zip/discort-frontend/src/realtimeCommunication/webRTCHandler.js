import { setLocalStream, setRemoteStream } from "../store/actions/roomActions";
import store from "../store/store";
import Peer from "simple-peer";
import { signalPeerData } from "./socketConnection";

const getConfiguration = () => {
  const turnIceServers = null;

  if (turnIceServers) {
  } else {
    console.warn("using only stun server");

    return {
      iceServers: [
        {
          urls: "stun:stun.l.google.com:19302",
        },
      ],
    };
  }
};

const onlyAudioConstraints = {
  audio: true,
  video: false,
};

const defaultConstraints = {
  video: true,
  audio: true,
};

let peers = {};

export const getLocalStreamPreview = (onlyAudio = false, callbackFunc) => {
  const constraints = onlyAudio ? onlyAudioConstraints : defaultConstraints;

  navigator.mediaDevices
    .getUserMedia(constraints)
    .then((stream) => {
      store.dispatch(setLocalStream(stream));
      callbackFunc();
    })
    .catch((err) => {
      console.log(err);
      console.log("Cannot get an access to local stream", err);
    });
};

export const prepareNewPeerConnection = (
  connectedUserSocketId,
  isInitiator
) => {
  const localStream = store.getState().room.localStream;

  if (isInitiator) {
    console.log("ini");
  } else {
    console.log("not ini");
  }

  peers[connectedUserSocketId] = new Peer({
    initiator: isInitiator,
    config: getConfiguration(),
    stream: localStream,
  });

  peers[connectedUserSocketId].on("signal", (data) => {
    const signalData = {
      signal: data,
      connectedUserSocketId: connectedUserSocketId,
    };

    console.log({ signalData });

    signalPeerData(signalData);
  });

  peers[connectedUserSocketId].on("stream", (remoteStream) => {
    console.log("remote stream data direct connection establised");

    remoteStream.connectedUserSocketId = connectedUserSocketId;
    addNewRemoteStream(remoteStream);
  });
};

export const handlingSignalData = (data) => {
  const { connectedUserSocketId, signal } = data;

  if (peers[connectedUserSocketId]) {
    peers[connectedUserSocketId].signal(signal);
  }
};

const addNewRemoteStream = (remoteStream) => {
  const remoteStreams = store.getState().room.remoteStream;

  const newRemoteStreams = [...remoteStreams, remoteStream];

  store.dispatch(setRemoteStream(newRemoteStreams));
};

export const closeAllConnection = () => {
  Object.entries(peers).forEach((mappedObject) => {
    const connectedUserSocketId = mappedObject[0];

    if (peers[connectedUserSocketId]) {
      peers[connectedUserSocketId].destroy();

      delete peers[connectedUserSocketId];
    }
  });
};

export const handleParticipantLeftRoom = (data) => {
  const { connectedUserSocketId } = data;

  if (peers[connectedUserSocketId]) {
    peers[connectedUserSocketId].destroy();

    delete peers[connectedUserSocketId];
  }

  const remoteStreams = store.getState().room.remoteStream;

  const newRemoteStreams = remoteStreams.filter((remoteStream) => {
    return remoteStream.connectedUserSocketId != connectedUserSocketId;
  });

  store.dispatch(setRemoteStream(newRemoteStreams));
};

export const switchOutgoingTracks = (stream) => {
  for (let socket_id in peers) {
    for (let index in peers[socket_id].streams[0].getTracks()) {
      for (let index2 in stream.getTracks()) {
        if (
          peers[socket_id].streams[0].getTracks()[index].kind ===
          stream.getTracks()[index2].kind
        ) {
          peers[socket_id].replaceTrack(
            peers[socket_id].streams[0].getTracks()[index],
            stream.getTracks()[index2],
            peers[socket_id].streams[0]
          );
          break;
        }
      }
    }
  }
};
