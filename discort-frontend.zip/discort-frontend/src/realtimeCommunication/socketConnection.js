import io from "socket.io-client";
import { updateDirectChatHIstoryIfActive } from "../shared/utils/chat";
import {
  setPendingFriendInvitation,
  setFriends,
  setOnlineUsers,
} from "../store/actions/friendsActions";
import store from "../store/store";
import { newRoomCreated, updateActiveRooms } from "./roomHandler";
import {
  handleParticipantLeftRoom,
  handlingSignalData,
  prepareNewPeerConnection,
} from "./webRTCHandler";

let socket = null;

export const connectWithSocketServer = (userDetails) => {
  const { token } = userDetails;

  socket = io("http://localhost:5002", {
    auth: {
      token: token,
    },
  });

  socket.on("connect", () => {
    console.log("Successfully connected with socket id  ", socket.id);
  });

  socket.on("friends-invitations", (data) => {
    const { pendingInvitations } = data;

    store.dispatch(setPendingFriendInvitation(pendingInvitations));
  });

  socket.on("friends-list", (data) => {
    const { friends } = data;

    store.dispatch(setFriends(friends));
  });

  socket.on("online-users", (data) => {
    let { onlineUsers } = data;
    console.log({ onlineUsers });
    store.dispatch(setOnlineUsers(onlineUsers));
  });

  socket.on("direct-chat-history", (data) => {
    updateDirectChatHIstoryIfActive(data);
  });

  socket.on("room-create", (data) => {
    newRoomCreated(data);
  });

  socket.on("active-rooms", (data) => {
    updateActiveRooms(data);
  });

  socket.on("conn-prepare", (data) => {
    const { connUserSocketId } = data;
    prepareNewPeerConnection(connUserSocketId, false);

    socket.emit("conn-init", {
      connUserSocketId,
    });
  });
  socket.on("conn-init", (data) => {
    const { connUserSocketId } = data;

    prepareNewPeerConnection(connUserSocketId, true);
  });
  socket.on("conn-signal", (data) => {
    handlingSignalData(data);
  });

  socket.on("room-participant-left", (data) => {
    console.log("user left room");

    handleParticipantLeftRoom(data);
  });
};

export const sendDirectMessage = (data) => {
  socket.emit("direct-message", data);
};

export const getDirectChatHistory = (data) => {
  socket.emit("direct-chat-history", data);
};

export const createNewRoom = () => {
  socket.emit("room-create");
};

export const joinRoom = (data) => {
  socket.emit("room-join", data);
};

export const leaveRoom = (data) => {
  socket.emit("room-leave", data);
};

export const signalPeerData = (data) => {
  socket.emit("conn-signal", data);
};
