import { ScreenShare, StopScreenShare } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import React, { useState } from "react";
import { switchOutgoingTracks } from "../../../realtimeCommunication/webRTCHandler";

const constraints = {
  audio: false,
  video: true,
};

const ScreenShareButton = ({
  localStream,
  screenSharingStream,
  setScreenSharingStream,
  isScreenSharingActive,
}) => {
  const handleToggleScreenShare = async () => {
    if (!isScreenSharingActive) {
      let stream = null;

      try {
        stream = await navigator.mediaDevices.getDisplayMedia(constraints);
      } catch (error) {
        console.log("screen share", error);
      }

      if (stream) {
        setScreenSharingStream(stream);

        switchOutgoingTracks(stream);
      }
    } else {
      switchOutgoingTracks(localStream);
      screenSharingStream.getTracks().forEach((t) => t.stop());
      setScreenSharingStream(null);
    }
    // setSCreenShareMicEnabled(!screenShareEnabled);
  };

  return (
    <IconButton onClick={handleToggleScreenShare} style={{ color: "white" }}>
      {!isScreenSharingActive ? <ScreenShare /> : <StopScreenShare />}
    </IconButton>
  );
};

export default ScreenShareButton;
