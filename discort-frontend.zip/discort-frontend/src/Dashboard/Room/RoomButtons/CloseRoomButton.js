import { Close } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import React, { useState } from "react";
import * as roomHandler from "../../../realtimeCommunication/roomHandler";

const CloseRoomButton = () => {
  const handleLeaveRoom = () => {
    roomHandler.leaveRoom();
  };

  return (
    <IconButton onClick={handleLeaveRoom} style={{ color: "white" }}>
      <Close />
    </IconButton>
  );
};

export default CloseRoomButton;
