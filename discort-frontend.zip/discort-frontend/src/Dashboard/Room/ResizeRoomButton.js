import { CloseFullscreen, OpenInFull } from "@mui/icons-material";
import { IconButton } from "@mui/material";
import { styled } from "@mui/system";
import React from "react";

const MainContainer = styled("div")({
  position: "absolute",
  bottom: "10px",
  right: "10px",
});

const ResizeRoomButton = ({ isRoomMinimized, roomResizeHandler }) => {
  return (
    <MainContainer>
      <IconButton
        style={{
          color: "white",
        }}
        onClick={roomResizeHandler}
      >
        {isRoomMinimized ? <OpenInFull /> : <CloseFullscreen />}
      </IconButton>
    </MainContainer>
  );
};

export default ResizeRoomButton;
