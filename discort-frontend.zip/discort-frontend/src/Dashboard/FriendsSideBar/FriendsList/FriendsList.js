import React from "react";
import { styled } from "@mui/system";
import FriendsListItem from "./FriendsListItem";
import { connect } from "react-redux";

const DummyFriends = [
  {
    _id: 1,
    username: "Mark",
    isOnline: true,
  },
  {
    _id: 2,
    username: "kavin",
    isOnline: false,
  },
  {
    _id: 3,
    username: "darran",
    isOnline: false,
  },
];

const MainContainer = styled("div")({
  flexGrow: 1,
  width: "100%",
});

const FriendsList = ({ friend, onlineUsers }) => {
  console.log({ onlineUsers });

  const checkOnlineUsers = (friend = [], onlineUsers = []) => {
    console.log({ friend });
    friend.forEach((f) => {
      const isUserOnline = onlineUsers.find((user) => {
        console.log({ user });

        return user.userId == f.id;
      });

      f.isOnline = isUserOnline ? true : false;
    });

    console.log({ friend });

    return friend;
  };

  return (
    <MainContainer>
      {checkOnlineUsers(friend, onlineUsers).map((f) => (
        <FriendsListItem
          username={f.username}
          id={f.id}
          key={f.id}
          isOnline={f.isOnline}
        />
      ))}
    </MainContainer>
  );
};

const mapStoreStateToProps = ({ friends }) => {
  console.log("reducer", friends);
  return {
    ...friends,
  };
};

export default connect(mapStoreStateToProps)(FriendsList);
