import { Typography } from "@mui/material";
import React from "react";

const FriendsTitle = ({ title }) => {
  return (
    <div>
      <Typography
        sx={{
          textTransform: "uppercase",
          color: "#8e9297",
          fontSize: "14px",
          marginTop: "10px",
        }}
      >
        {title}
      </Typography>
    </div>
  );
};

export default FriendsTitle;
