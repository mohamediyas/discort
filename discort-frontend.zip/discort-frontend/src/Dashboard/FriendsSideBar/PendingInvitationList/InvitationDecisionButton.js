import React from "react";
import { Check, Clear, Dialpad } from "@mui/icons-material";
import { Box, IconButton } from "@mui/material";

const InvitationDecisionButton = ({
  disabled,
  acceptInvitationHandler,
  rejectInvitationHandler,
}) => {
  return (
    <Box
      sx={{
        display: "flex",
      }}
    >
      <IconButton
        style={{ color: "white" }}
        disabled={disabled}
        onClick={acceptInvitationHandler}
      >
        <Check />
      </IconButton>

      <IconButton
        style={{ color: "white" }}
        disabled={disabled}
        onClick={rejectInvitationHandler}
      >
        <Clear />
      </IconButton>
    </Box>
  );
};

export default InvitationDecisionButton;
