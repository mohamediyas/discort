import React from "react";
import { styled } from "@mui/system";
import PendingInvitations from "./PendingInvitations";
import { connect } from "react-redux";

const DUMMY_INVIT = [
  {
    _id: "1",
    senderId: {
      username: "mark",
      email: "mark@gmail.com",
    },
  },
  {
    _id: "2",
    senderId: {
      username: "maik",
      email: "maik@gmail.com",
    },
  },
  {
    _id: "3",
    senderId: {
      username: "karankaran",
      email: "lkaran@gmail.com",
    },
  },
];

const MainContainer = styled("div")({
  width: "100%",
  height: "22%",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  overflow: "auto",
});

const PendingInvitationList = ({ pendingFriendsInvitation }) => {
  console.log({ pendingFriendsInvitation });
  return (
    <MainContainer>
      {pendingFriendsInvitation?.map((invit) => (
        <PendingInvitations
          key={invit._id}
          id={invit._id}
          username={invit.senderId.username}
          email={invit.senderId.email}
        />
      ))}
    </MainContainer>
  );
};

const mapStoreStateToProps = ({ friends }) => {
  console.log(friends);
  return {
    ...friends,
  };
};

export default connect(mapStoreStateToProps, null)(PendingInvitationList);
