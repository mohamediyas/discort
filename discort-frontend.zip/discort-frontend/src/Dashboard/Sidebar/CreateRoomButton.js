import { Add } from "@mui/icons-material";
import { Button } from "@mui/material";
import React from "react";
import * as roomHandler from "../../realtimeCommunication/roomHandler";

const CreateRoomButton = ({ isUserInRoom }) => {
  const createRoomHAndler = () => {
    // creating a room and server
    roomHandler.createNewRoom();
  };

  return (
    <div>
      <Button
        disabled={isUserInRoom}
        onClick={createRoomHAndler}
        style={{
          width: "48px",
          height: "48px",
          borderRadius: "16px",
          margin: 0,
          padding: 0,
          minWidth: 0,
          marginTop: "10px",
          color: "white",
          backgroundColor: "#5865F2",
        }}
      >
        <Add />
      </Button>
    </div>
  );
};

export default CreateRoomButton;
