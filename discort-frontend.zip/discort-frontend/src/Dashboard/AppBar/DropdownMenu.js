import { MoreVert } from "@mui/icons-material";
import { IconButton, Menu, MenuItem } from "@mui/material";
import React, { useState } from "react";
import { connect } from "react-redux";
import { logout } from "../../shared/utils/auth";
import { getActions } from "../../store/actions/roomActions";

const DropdownMenu = ({ audioOnly, setAudioOnly }) => {
  const [anchorE1, setAnchorE1] = useState(null);

  const open = Boolean(anchorE1);
  const handleMenuOpen = (e) => {
    setAnchorE1(e.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorE1(null);
  };

  const handleAudioOnly = () => {
    setAudioOnly(!audioOnly);
  };

  return (
    <div>
      <IconButton
        style={{
          color: "white",
        }}
        onClick={handleMenuOpen}
      >
        <MoreVert />
      </IconButton>
      <Menu
        open={open}
        MenuListProps={{
          "aria-labelledby": "basic-button",
        }}
        id="basic-menu"
        anchorEl={anchorE1}
        onClose={handleMenuClose}
      >
        <MenuItem onClick={logout}>Logout</MenuItem>
        <MenuItem onClick={handleAudioOnly}>
          {audioOnly ? "Audio Only Enabled" : "Audio Only Disabled"}
        </MenuItem>
      </Menu>
    </div>
  );
};

const mapStoreStateToProps = ({ room }) => {
  return {
    ...room,
  };
};

const mapActionsToProps = (dispatch) => {
  return {
    ...getActions(dispatch),
  };
};

export default connect(mapStoreStateToProps, mapActionsToProps)(DropdownMenu);
