import store from "../../store/store";
import { setMessages } from "../../store/actions/chatActions";

export const updateDirectChatHIstoryIfActive = (data) => {
  const { participants, messages } = data;

  const receiverId = store.getState().chat.chosenChatDetails?.id;
  const userId = store.getState().auth.userDetail._id;

  console.log(receiverId, userId, "CHECK");

  if (receiverId && userId) {
    const userInConversation = [receiverId, userId];

    updateChatHistoryIfSameConvertionActive({
      participants,
      userInConversation,
      messages,
    });
  }
};
const updateChatHistoryIfSameConvertionActive = ({
  participants,
  userInConversation,
  messages,
}) => {
  const result = participants.every((participantId) => {
    return userInConversation.includes(participantId);
  });

  if (result) {
    store.dispatch(setMessages(messages));
  }
};
