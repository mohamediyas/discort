const mongoose = require("mongoose");

const SChema = mongoose.Schema;

const friendInvitationSchema = new SChema({
  senderId: {
    type: SChema.Types.ObjectId,
    ref: "user",
  },
  receiverId: {
    type: SChema.Types.ObjectId,
    ref: "user",
  },
});

module.exports = mongoose.model("FriendInvitation", friendInvitationSchema);
