const Conversation = require("../../models/conversation");

const serverStore = require("../../serverStore");

const updateChatHistory = async (conversationId, toSpecificSocketId = null) => {
  const conversation = await Conversation.findById(conversationId).populate({
    path: "messages",
    model: "message",
    populate: {
      path: "author",
      model: "user",
      select: "username _id",
    },
  });

  if (conversation) {
    const io = serverStore.getSockerServerInstance();

    if (toSpecificSocketId) {
      return io.to(toSpecificSocketId).emit("direct-chat-history", {
        messages: conversation.messages,
        participants: conversation.participants,
      });
    }

    conversation.participants.forEach((userId) => {
      const activeConnections = serverStore.getActiveConnection(
        userId.toString()
      );

      activeConnections.forEach((socketId) => {
        io.to(socketId).emit("direct-chat-history", {
          messages: conversation.messages,
          participants: conversation.participants,
        });
      });
    });
  }
};

module.exports = {
  updateChatHistory,
};
