const USer = require("../../models/user");
const FriendInvitation = require("../../models/friendInvitation");

const serverStore = require("../../serverStore");

const updateFriendsPendingInvitation = async (userId) => {
  try {
    const pendingInvitation = await FriendInvitation.find({
      receiverId: userId,
    }).populate("senderId", "_id username email");

    const revceiverList = serverStore.getActiveConnection(userId);

    const io = serverStore.getSockerServerInstance();

    revceiverList.forEach((receiverSocketId) => {
      io.to(receiverSocketId).emit("friends-invitations", {
        pendingInvitations: pendingInvitation ? pendingInvitation : [],
      });
    });
  } catch (error) {
    console.log(error);
  }
};

const updateFriends = async (userId) => {
  try {
    const receiverList = serverStore.getActiveConnection(userId);

    if (receiverList.length > 0) {
      const user = await USer.findById(userId, { _id: 1, friends: 1 }).populate(
        "friends",
        "_id username email"
      );

      if (user) {
        const FriendsList = user.friends.map((f) => {
          return {
            id: f._id,
            email: f.email,
            username: f.username,
          };
        });

        const io = serverStore.getSockerServerInstance();

        receiverList.forEach((receiverSocketId) => {
          io.to(receiverSocketId).emit("friends-list", {
            friends: FriendsList ? FriendsList : [],
          });
        });
      }
    }
  } catch (error) {
    console.log(error);
  }
};

module.exports = {
  updateFriendsPendingInvitation,
  updateFriends,
};
