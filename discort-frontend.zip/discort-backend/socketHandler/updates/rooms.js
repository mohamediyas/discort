const serverStore = require("../../serverStore");

const updateRoom = (toSpecificTargetId = null) => {
  const io = serverStore.getSockerServerInstance();

  const activeRooms = serverStore.getActiveRooms();

  if (toSpecificTargetId) {
    io.to(toSpecificTargetId).emit("active-rooms", {
      activeRooms,
    });
  } else {
    io.emit("active-rooms", {
      activeRooms,
    });
  }
};

module.exports = {
  updateRoom,
};
