const serverStore = require("../serverStore");
const { updateRoom } = require("./updates/rooms");

const roomCreateHandler = (socket) => {
  console.log("handling room create");

  console.log(socket.user);

  const socketId = socket.id;

  const userId = socket.user.userId;

  const roomDetails = serverStore.addNewActiveRoom(userId, socketId);

  socket.emit("room-create", {
    roomDetails,
  });

  updateRoom();
};

module.exports = roomCreateHandler;
