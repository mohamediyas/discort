const postLogin = require("./postLogin");
const postRegister = require("./postRegister");

module.exports = {
  postLogin,
  postRegister,
};
