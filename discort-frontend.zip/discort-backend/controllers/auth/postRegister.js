const User = require("../../models/user");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const postRegister = async (req, res) => {
  try {
    const { username, email, password } = req.body;

    const userExist = await User.exists({ email: email.toLowerCase() });

    if (userExist) {
      return res.status(409).send("email already exist");
    }

    // encrypt password

    const encryptPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      username,
      password: encryptPassword,
      email: email.toLowerCase(),
    });

    // create jwt

    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email,
      },
      process.env.TOKEN_KEY,
      {
        expiresIn: "24h",
      }
    );

    res.status(201).send({ ...user._doc, token });
  } catch (error) {
    res.status(500).send("Error occured");
  }
};

module.exports = postRegister;
