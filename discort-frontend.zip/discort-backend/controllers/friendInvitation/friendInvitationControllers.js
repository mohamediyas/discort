const Invitation = require("../../models/friendInvitation");
const User = require("../../models/user");
const {
  updateFriendsPendingInvitation,
  updateFriends,
} = require("../../socketHandler/updates/friends");

const postInvite = async (req, res) => {
  const { email: targetEmail } = req.body;

  const { userId, email } = req.user;

  // check if friend that we
  if (email.toLowerCase() == targetEmail.toLowerCase()) {
    return res
      .status(409)
      .send("Sorry . you can't become friend with yourself");
  }

  const targetUser = await User.findOne({
    email: targetEmail.toLowerCase(),
  });

  if (!targetUser) {
    return res.status(404).send("user not found");
  }

  // check if invitation has already send

  const invitationAlreadySend = await Invitation.findOne({
    senderId: userId,
    receiverId: targetUser._id,
  });

  if (invitationAlreadySend) {
    return res.status(409).send("Invitation already send");
  }

  // check user already friend

  const userAlreadyFriend = targetUser.friends.find(
    (f) => f.toString() == userId.toString()
  );

  if (userAlreadyFriend) {
    return res.status(409).send("You are already in friend list");
  }

  // create new Invitation

  const newInvitation = await Invitation.create({
    senderId: userId,
    receiverId: targetUser._id,
  });

  updateFriendsPendingInvitation(targetUser._id.toString());

  return res.status(201).send("Inviatation has been send");
};

const postAccept = async (req, res) => {
  try {
    const { id } = req.body;

    const invitation = await Invitation.findById(id);

    if (!invitation) {
      return res.status(401).send("Error occured please try again");
    }

    const { senderId, receiverId } = invitation;

    const senderUser = await User.findById(senderId);

    senderUser.friends = [...senderUser.friends, receiverId];

    const receiverUser = await User.findById(receiverId);

    receiverUser.friends = [...receiverUser.friends, senderId];

    await senderUser.save();

    await receiverUser.save();

    await Invitation.findByIdAndDelete(id);

    updateFriends(senderId.toString());

    updateFriends(receiverId.toString());

    updateFriendsPendingInvitation(receiverId.toString());

    return res.send("Invitation accepted");
  } catch (error) {
    console.log(error);
    return res.status(500).send("something went wrong");
  }
};

const postReject = async (req, res) => {
  try {
    const { id } = req.body;

    const { userId } = req.user;

    const invitationExist = await Invitation.exists({
      _id: id,
    });

    if (invitationExist) {
      await Invitation.findByIdAndDelete(id);
    }

    updateFriendsPendingInvitation(userId);

    return res.status(200).send("invitation reject");
  } catch (error) {
    console.log(error);
    return res.status(500).send("something went wrong");
  }
};

module.exports = {
  postInvite,
  postAccept,
  postReject,
};
