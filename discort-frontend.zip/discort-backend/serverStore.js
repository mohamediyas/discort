const { v4: uuidv4 } = require("uuid");

const connectedUser = new Map();
let activeRooms = [];

let io;

const setSocketServerInstance = (ioInstance) => {
  io = ioInstance;
};

const getSockerServerInstance = () => {
  return io;
};

const addNewConnectedUser = ({ socketId, userId }) => {
  connectedUser.set(socketId, { userId });

  console.log("new connected user", connectedUser);
};

const removeConnectedUser = (socketId) => {
  if (connectedUser.has(socketId)) {
    connectedUser.delete(socketId);
    console.log("new connected user", connectedUser);
  }
};

const getActiveConnection = (userId) => {
  const activeConnection = [];

  connectedUser.forEach((value, key) => {
    if (value.userId == userId) {
      activeConnection.push(key);
    }
  });

  return activeConnection;
};

const getOnlineUser = () => {
  const onlineUser = [];

  connectedUser.forEach((value, key) => {
    onlineUser.push({ socketId: key, userId: value.userId });
  });

  return onlineUser;
};

const addNewActiveRoom = (userId, socketId) => {
  const newActiveRoom = {
    roomCreator: {
      userId,
      socketId,
    },
    participants: [
      {
        userId,
        socketId,
      },
    ],
    roomId: uuidv4(),
  };
  activeRooms = [...activeRooms, newActiveRoom];

  console.log("ROOM", activeRooms);

  return newActiveRoom;
};

const getActiveRooms = () => {
  return [...activeRooms];
};

const getActiveRoom = (roomId) => {
  const activeRoom = activeRooms.find(
    (activeRoom) => activeRoom.roomId == roomId
  );

  if (activeRoom) {
    return {
      ...activeRoom,
    };
  } else {
    return null;
  }
};

const joinActiveRoom = (roomId, participantDetails) => {
  const room = activeRooms.find((room) => room.roomId == roomId);

  activeRooms = activeRooms.filter((room) => room.roomId != roomId);

  console.log({ room });

  const updatedRoom = {
    ...room,
    participants: [...room.participants, participantDetails],
  };

  console.log({ updatedRoom });

  activeRooms.push(updatedRoom);

  console.log(activeRooms);
};

const leaveActiveRoom = (roomId, participantSocketId) => {
  const activeRoom = activeRooms.find((room) => room.roomId == roomId);

  if (activeRoom) {
    const copyOfActiveRoom = { ...activeRoom };

    copyOfActiveRoom.participants = copyOfActiveRoom.participants.filter(
      (partcipant) => partcipant.socketId != participantSocketId
    );

    activeRooms = activeRooms.filter((room) => room.roomId != roomId);

    if (copyOfActiveRoom.participants.length > 0) {
      activeRooms.push(copyOfActiveRoom);
    }
  }
};

module.exports = {
  addNewConnectedUser,
  removeConnectedUser,
  getActiveConnection,
  getSockerServerInstance,
  setSocketServerInstance,
  getOnlineUser,
  addNewActiveRoom,
  getActiveRooms,
  getActiveRoom,
  joinActiveRoom,
  leaveActiveRoom,
};
